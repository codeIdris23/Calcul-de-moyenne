#coding:utf-8

n =int(input("liste de note?"))
S =0
for a in range(1,n+1):
 note =float(input("NOTE?"))
 S =S+note
print(S/n)



